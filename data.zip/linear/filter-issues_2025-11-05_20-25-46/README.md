# Task: Filter Issues in Linear
**Goal:** Capture of modal-based invite workflow.

**States captured:**
- `01_loaded.png`
- `02_filter_open.png`
- `03_filter_applied.png`

**Notes:** Automatically captured using heuristic agent.
