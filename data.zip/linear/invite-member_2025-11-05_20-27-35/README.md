# Task: Invite a Member in Linear
**Goal:** Capture of modal-based invite workflow.

**States captured:**
- `01_loaded.png`
- `02_invite_modal.png`
- `03_email_filled.png`
- `04_invite_sent.png`

**Notes:** Automatically captured using heuristic agent.
