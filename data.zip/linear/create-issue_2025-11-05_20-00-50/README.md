# Task: Create an Issue in Linear
**Goal:** Capture of modal-based invite workflow.

**States captured:**
- `01_loaded.png`
- `02_modal.png`
- `03_filled.png`
- `04_success_toast.png`

**Notes:** Automatically captured using heuristic agent.
